const category = document.getElementById("category");
const model = document.getElementById("model");
const serialNumber = document.getElementById("serialNumber");
const date = document.getElementById("date");
const fileItem = document.getElementById("fileInput");
const form = document.getElementById("form");
const errorElement = document.getElementById("error")
var input = document.getElementById("fileInput");
var infoArea = document.getElementById("file-upload-filename");

form.addEventListener('submit', (e)=>{
    let messages =[]
    if(serialNumber.value === '' || serialNumber.value == null){
        messages.push("Serial Number is required")
    }

    if (category.selectedIndex == "") {
      messages.push("Category is required");
    }

    if (model.selectedIndex == "") {
      messages.push("Model is required");
    }
    if (date.value == "") {
      messages.push("Date is required");
    }
    if (fileItem.files.length == 0) {
      messages.push("File is required");
    }
    if(messages.length > 0){
        e.preventDefault();
        errorElement.innerText = messages.join("\n")
    }
}

)





input.addEventListener("change", showFileName);

function showFileName(event) {
  var input = event.srcElement;
  var fileName = input.files[0].name;
  infoArea.textContent = "File name: " + fileName;
}

