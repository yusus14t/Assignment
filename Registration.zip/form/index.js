var express = require("express");
var connection = require("./db");
const app = express();
const bodyParser = require("body-parser");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static("public"));

app.get("/register", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

app.post("/submit", (req, res) => {
  let category = req.body.category;
  let model = req.body.model;
  let serial_number = req.body.serialNumber;
  let date = req.body.date;
  let file = req.body.file;

  // res.send(req.body);
  connection.connect(function (err) {
    if (err) {
      console.log(err);
    } else {
      let mysql = `INSERT INTO user(category, model, serial_number, date, file) VALUES(?, ?, ?, ?, ?)`;

      connection.query(
        mysql,
        [category, model, serial_number, date, file],
        (err, result) => {
          if (err) {
            console.log(err);
          } else {
            res.send("Register Successfully");
          }
        }
      );
    }
  });
});

app.listen(7000);
